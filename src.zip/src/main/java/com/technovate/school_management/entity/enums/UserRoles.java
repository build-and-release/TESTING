package com.technovate.school_management.entity.enums;

public enum UserRoles {
    ADMIN,
    STUDENT,
    TEACHER,
    MANAGEMENT,
    STAFF,
    USER,
    GUARDIAN
}
