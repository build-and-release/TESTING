package com.technovate.school_management.entity.enums;

public enum ClassLevelEnum {
    PREKINDERGARTEN,
    KINDERGARTEN,
    PRIMARY,
    SECONDARY
}
