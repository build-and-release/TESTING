package com.technovate.school_management.entity.enums;

public enum SchoolTerm {
    FIRST,
    SECOND,
    THIRD
}
